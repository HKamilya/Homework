INSERT INTO users (username, password, role, SlackId)
VALUES ('admin', '{noop}admin', 'ADMIN', '');
INSERT INTO users (username, password, role, SlackId)
VALUES ('Salavat Zabirov', '{noop}salavat', 'USER', 'UAD5LG6KY');
INSERT INTO users (username, password, role, SlackId)
VALUES ('Nick', '{noop}nick', 'USER', 'UADA6JZ9V');
INSERT INTO users (username, password, role, SlackId)
VALUES ('Kamilya', '{noop}kamilya', 'USER', 'UABHLB4QG');
